<?php
// Opdracht 2: zelfde dagdeel, maar nu met een match-statement
$uur = date("G"); // 0 t/m 23

$dagdeel = match (true) {
    $uur >= 6 && $uur < 12 => "ochtend",
    $uur >= 12 && $uur < 18 => "middag",
    $uur >= 18 && $uur < 24 => "avond",
    default => "nacht",
};

echo "Het is " . $dagdeel . ".";
?>
