<?php
// Opdracht 3: grootste van twee getallen * 2 + het andere getal
$getal1 = 10;
$getal2 = 15;

if ($getal1 > $getal2) {
    $grootste = $getal1;
    $ander = $getal2;
} else {
    $grootste = $getal2;
    $ander = $getal1;
}

$uitkomst = $grootste * 2 + $ander;

echo "Uitkomst: " . $uitkomst;
?>
