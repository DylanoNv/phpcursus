<?php
// Opdracht 4: prijsverhoging aan de hand van oude prijs
$oudePrijs = 100;

if ($oudePrijs > 150) {
    $percentage = 19;
} elseif ($oudePrijs < 55) {
    $percentage = 11;
} else {
    $percentage = 16;
}

$nieuwePrijs = $oudePrijs + ($oudePrijs * $percentage / 100);

echo "Oude prijs: € " . $oudePrijs . ". Na verhoging van " . $percentage .
     "% is de prijs: € " . $nieuwePrijs . ".";
?>
